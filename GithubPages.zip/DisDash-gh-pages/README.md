# DisDash

A modern, stripped discord bot dashboard, designed with minimal coding requirements in mind!

![](./assets/img/Screenshot.png)

# Setup

You can setup the website in two easy steps, **Note: This is a basic setup and if you want to use it properly, take the time to look through all the code, and understand what is going on so you can change it in future**

1. Run ``npm install`` in your command prompt
2. In assets/js/replacement.js change botName to whatever the name of your bot is. Then commit your changes and boom! All done!

**IMPORTANT NOTE: ANY TIME YOU CHANGE ANYTHING IN REPLACEMENT.JS, REMEMBER TO RUN BundleCode.sh OTHERWISE IT WILL NOT WORK!**

## Contacts
jamesinaxx - jamesina#1111 on Discord
Abdennour Mez – [abdennour.mez160@gmail.com](mailto:abdennour.mez160@gmail.com)

See ``LICENSE`` for more info on the legal stuff

Created by:
- [jamesinaxx](https://github.com/jamesinaxx)
- [NouNouDz](https://github.com/NouNouDz) 
